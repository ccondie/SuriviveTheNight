package mapbuilder;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.*;

public class MapBuilder {
	
	private final int GRASS1 = 0;
	private final int GRASS2 = 1;
	private final int GRASS3 = 2;
	private final int GRASS4 = 3;
	private final int GRASS = 0;
	private final int TILE = 1;
	private final int NORTH = 2;
	private final int WEST = 3;
	private final int EAST = 4;
	private final int SOUTH = 5;
	private final int NORTHWEST = 6;
	private final int NORTHEAST = 7;
	private final int SOUTHWEST = 8;
	private final int SOUTHEAST = 9;
	private final int INORTHWEST = 10;
	private final int INORTHEAST = 11;
	private final int ISOUTHWEST = 12;
	private final int ISOUTHEAST = 13;
	private final int NW_SE = 14;
	private final int NE_SW = 15;
	private final int EMPTY = 0;
	private final int WALL = 1;
	private final int WINDOW = 2;
	private final int DOORH = 3;
	private final int DOORV = 4;
	
	private final int GRASSCOUNT = 4;
	private final int TILECOUNT = 16;
	private final int WALLCOUNT = 5;
	private final int GRIDWIDTH = 20;
	private final int GRIDHEIGHT = 20;
	private final int SQUAREPIXELS = 60;
	private final String PATH = "resources";
	
	private BufferedImage[] grass;
	private BufferedImage[] floor;
	private BufferedImage[] wall;
	
	private JFrame frame;
	
	private JMenu fileMenu;
	private JMenuBar menuBar;
	private JMenuItem menuOpen;
	private JMenuItem menuSave;
	private JFileChooser fileChooser;
	private File file;
	
	private JPanel layerPanel;
	private JPanel activePanel;
	private JPanel tilePanel;
	private JPanel blockPanel;
	private JPanel sidePanel;
	private JPanel mapPanel;
	
	private JScrollPane mapPane;
	private JScrollPane tilePane;
	private JViewport tileViewport;
	
	private JLabel selectLabel;
	
	private MapSquare[][] map;
	
	private JButton floorbtn;
	private JButton wallbtn;
	private JButton clearbtn;
	private JButton[] tileButton;
	private JButton[] blockButton;
	
	private JCheckBox sbCheck;
	
	private int curFloor;
	private int curWall;
	
	private Random random;
	private boolean showWalls;
	private boolean smartBuild;
	
	private int[][] grassmap;
	private int[][] floormap;
	private int[][] wallmap;
	
	public static void main(String[] args) {
		new MapBuilder();
	}
	
	public MapBuilder() {
		random = new Random();
		buildGUI();
	}
	
	private void buildGUI() {
		
		showWalls = false;
		smartBuild = false;
		grass = new BufferedImage[GRASSCOUNT];
		floor = new BufferedImage[TILECOUNT];
		wall = new BufferedImage[WALLCOUNT];
		
		try { 
			grass[GRASS1] = ImageIO.read(getClass().getResource("/grass1.png"));
			grass[GRASS2] = ImageIO.read(getClass().getResource("/grass2.png"));
			grass[GRASS3] = ImageIO.read(getClass().getResource("/grass3.png"));
			grass[GRASS4] = ImageIO.read(getClass().getResource("/grass4.png"));
			floor[GRASS] = grass[GRASS3];
			floor[TILE] = ImageIO.read(getClass().getResource("/floor_tiles.png"));
			floor[NORTH] = ImageIO.read(getClass().getResource("/divider_north.png"));
			floor[WEST] = ImageIO.read(getClass().getResource("/divider_west.png"));
			floor[EAST] = ImageIO.read(getClass().getResource("/divider_east.png"));
			floor[SOUTH] = ImageIO.read(getClass().getResource("/divider_south.png"));
			floor[NORTHWEST] = ImageIO.read(getClass().getResource("/divider_nw.png"));
			floor[NORTHEAST] = ImageIO.read(getClass().getResource("/divider_ne.png"));
			floor[SOUTHWEST] = ImageIO.read(getClass().getResource("/divider_sw.png"));
			floor[SOUTHEAST] = ImageIO.read(getClass().getResource("/divider_se.png"));
			floor[INORTHWEST] = ImageIO.read(getClass().getResource("/divider_nw_int.png"));
			floor[INORTHEAST] = ImageIO.read(getClass().getResource("/divider_ne_int.png"));
			floor[ISOUTHWEST] = ImageIO.read(getClass().getResource("/divider_sw_int.png"));
			floor[ISOUTHEAST] = ImageIO.read(getClass().getResource("/divider_se_int.png"));
			floor[NW_SE] = ImageIO.read(getClass().getResource("/divider_nwse.png"));
			floor[NE_SW] = ImageIO.read(getClass().getResource("/divider_nesw.png"));
			wall[EMPTY] = ImageIO.read(getClass().getResource("/empty.png"));
			wall[WALL] = ImageIO.read(getClass().getResource("/wall.png"));
			wall[WINDOW] = ImageIO.read(getClass().getResource("/window.png"));
			wall[DOORH] = ImageIO.read(getClass().getResource("/door_horiz.png"));
			wall[DOORV] = ImageIO.read(getClass().getResource("/door_vert.png"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		curFloor = 0;
		curWall = 1;
		selectLabel = new JLabel(new ImageIcon(floor[curFloor]));
		
		floorbtn = new JButton("Floor Layer");
		floorbtn.setActionCommand("F0");
		floorbtn.addActionListener(new ButtonClickListener());
		
		wallbtn = new JButton("Wall Layer");
		wallbtn.setActionCommand("W0");
		wallbtn.addActionListener(new ButtonClickListener());
		
		sbCheck = new JCheckBox("Use Smart Wall Builder");
		sbCheck.addActionListener(new CheckBoxListener());
		
		clearbtn = new JButton("Clear Map");
		clearbtn.setActionCommand("C0");
		clearbtn.addActionListener(new ButtonClickListener());
		
		layerPanel = new JPanel();
		layerPanel.add(floorbtn);
		layerPanel.add(wallbtn);
		layerPanel.add(sbCheck);
		layerPanel.add(clearbtn);
		
		activePanel = new JPanel();
		activePanel.setPreferredSize(new Dimension(100, 100));
		activePanel.setLayout(new BorderLayout());
		activePanel.setBackground(Color.gray);
		activePanel.add(selectLabel, BorderLayout.CENTER);
		
		tilePanel = new JPanel();
		tilePanel.setLayout(new BoxLayout(tilePanel, BoxLayout.Y_AXIS));
		tileButton = new JButton[TILECOUNT];
		for(int i=0; i<TILECOUNT; i++) {
			tileButton[i] = new JButton(new ImageIcon(floor[i]));
			tileButton[i].setActionCommand("f" + i);
			tileButton[i].addActionListener(new ButtonClickListener());
			tileButton[i].setAlignmentX(Component.CENTER_ALIGNMENT);
			tilePanel.add(tileButton[i]);
		}
		tilePane = new JScrollPane(tilePanel);
		tilePane.getVerticalScrollBar().setUnitIncrement(10);
		tileViewport = tilePane.getViewport();

		blockPanel = new JPanel();
		blockPanel.setLayout(new BoxLayout(blockPanel, BoxLayout.Y_AXIS));
		blockButton = new JButton[WALLCOUNT];
		for(int i=0; i<WALLCOUNT; i++) {
			blockButton[i] = new JButton(new ImageIcon(wall[i]));
			blockButton[i].setActionCommand("w" + i);
			blockButton[i].addActionListener(new ButtonClickListener());
			blockButton[i].setAlignmentX(Component.CENTER_ALIGNMENT);
			blockPanel.add(blockButton[i]);
		}
		
		sidePanel = new JPanel();
		sidePanel.setLayout(new BorderLayout());
		sidePanel.add(activePanel, BorderLayout.PAGE_START);
		sidePanel.add(tilePane, BorderLayout.CENTER);
		
		mapPanel = new JPanel();
		mapPanel.setPreferredSize(new Dimension(GRIDWIDTH * SQUAREPIXELS, GRIDHEIGHT * SQUAREPIXELS));
		mapPanel.setLayout(new GridLayout(GRIDHEIGHT, GRIDWIDTH));
		mapPanel.setBackground(Color.black);
		mapPane = new JScrollPane(mapPanel);
		mapPane.getHorizontalScrollBar().setUnitIncrement(10);
		mapPane.getVerticalScrollBar().setUnitIncrement(10);
		
		map = new MapSquare[GRIDHEIGHT][];
		grassmap = new int[GRIDHEIGHT][];
		floormap = new int[GRIDHEIGHT][];
		wallmap = new int[GRIDHEIGHT][];
		for(int i=0; i<GRIDHEIGHT; i++) {
			map[i] = new MapSquare[GRIDWIDTH];
			grassmap[i] = new int[GRIDWIDTH];
			floormap[i] = new int[GRIDWIDTH];
			wallmap[i] = new int[GRIDWIDTH];
			for(int j=0; j<GRIDWIDTH; j++) {
				grassmap[i][j] = random.nextInt(GRASSCOUNT);
				floormap[i][j] = wallmap[i][j] = 0;
				map[i][j] = new MapSquare(i, j);
				map[i][j].addMouseListener(map[i][j]);
				mapPanel.add(map[i][j]);
			}
		}
		
		menuOpen = new JMenuItem("Open");
		menuSave = new JMenuItem("Save");
		fileMenu = new JMenu("File");
		menuBar = new JMenuBar();
		
		menuOpen.addActionListener(new OpenListener());
		menuSave.addActionListener(new SaveListener());
		fileMenu.add(menuOpen);
		fileMenu.add(menuSave);
		menuBar.add(fileMenu);

		frame = new JFrame("Survive The Night Map Builder");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1200, 800);
		frame.setJMenuBar(menuBar);
		frame.setLayout(new BorderLayout());
		frame.add(layerPanel, BorderLayout.PAGE_START);
		frame.add(sidePanel, BorderLayout.LINE_START);
		frame.add(mapPane, BorderLayout.CENTER);
	    frame.setVisible(true);
	}
	
	public void ClearMap() {
		for(int i=0; i<GRIDHEIGHT; i++)
			for(int j=0; j<GRIDWIDTH; j++)
				floormap[i][j] = wallmap[i][j] = 0;
	}
	
	public void RefreshMap() {
		for (MapSquare[] mr: map)
		    for (MapSquare ms: mr)
		    	ms.repaint();
	}
	
	private class OpenListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			fileChooser = new JFileChooser();
			if(fileChooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
				file = fileChooser.getSelectedFile();
				if (!file.exists())
					return;
				FileInputStream fis = null;
		        ObjectInputStream ois = null;
				try {
					fis = new FileInputStream(file);
					ois = new ObjectInputStream(fis);
					floormap = (int[][]) ois.readObject();
					wallmap = (int[][]) ois.readObject();
					RefreshMap();
				} catch (IOException ex) {
					ex.printStackTrace();
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				} finally {
					try {
						if (ois != null)
							ois.close();
						if (fis != null)
							fis.close();
					} catch (IOException exc) {
						exc.printStackTrace();
					}
				}
			}
		}
	}
	
	private class SaveListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			fileChooser = new JFileChooser();
			if(fileChooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {
				file = fileChooser.getSelectedFile();
				FileOutputStream fos = null;
		        ObjectOutputStream oos = null;
				try {
					if (!file.exists())
						file.createNewFile();
					fos = new FileOutputStream(file);
					oos = new ObjectOutputStream(fos);
					oos.writeObject(floormap);
					oos.writeObject(wallmap);
				} catch (IOException ex) {
					ex.printStackTrace();
				} finally {
					try {
						if (oos != null)
							oos.close();
						if (fos != null)
							fos.close();
					} catch (IOException exc) {
						exc.printStackTrace();
					}
				}
			}
		}
	}
	
	private class CheckBoxListener  implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			smartBuild = sbCheck.isSelected();
			tileButton[GRASS].setVisible(!smartBuild);
			for(int i = NORTH; i < TILECOUNT; i++)
				tileButton[i].setVisible(!smartBuild);
			curFloor = TILE;
			if(smartBuild && !showWalls)
				selectLabel.setIcon(new ImageIcon(floor[curFloor]));
		}
		
	}
	
	private class ButtonClickListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			String command = e.getActionCommand();
			int opt = Integer.parseInt(command.substring(1));
			switch(command.charAt(0)) {
			case 'f':
				curFloor = opt;
				selectLabel.setIcon(new ImageIcon(floor[curFloor]));
				break;
			case 'w':
				curWall = opt;
				selectLabel.setIcon(new ImageIcon(wall[curWall]));
				break;
			case 'F':
				showWalls = false;
				selectLabel.setIcon(new ImageIcon(floor[curFloor]));
				tileViewport.remove(tileViewport.getComponents()[0]);
				tileViewport.add(tilePanel);
				RefreshMap();
				break;
			case 'W':
				showWalls = true;
				selectLabel.setIcon(new ImageIcon(wall[curWall]));
				tileViewport.remove(tileViewport.getComponents()[0]);
				tileViewport.add(blockPanel);
				RefreshMap();
				break;
			case 'C':
				ClearMap();
				RefreshMap();
			}
		}		
	}
	
	private class MapSquare extends JPanel implements MouseListener {

		private static final long serialVersionUID = -1764905696439049961L;
		private int row;
		private int col;

		public MapSquare(int row, int col) {
			this.row = row;
			this.col = col;
		}

		@Override
		public void mouseClicked(MouseEvent e) {}

		@Override
		public void mousePressed(MouseEvent e) {
			if(!showWalls) {
				floormap[row][col] = curFloor;
				if(smartBuild) {
					if(curFloor > 1 && wallmap[row][col] == EMPTY)
						wallmap[row][col] = WALL;
					else if(curFloor == 1) {
						wallmap[row][col] = EMPTY;
						// check north
						if(row-1>=0) {
							wallmap[row-1][col] = WALL;
							switch(floormap[row-1][col]) {
							case GRASS:
							case NORTHWEST:
							case NORTHEAST:
								floormap[row-1][col] = NORTH;
								break;
							case SOUTH:
							case ISOUTHWEST:
							case ISOUTHEAST:
								floormap[row-1][col] = TILE;
							case TILE:
								wallmap[row-1][col] = EMPTY;
								break;
							case WEST:
							case SOUTHWEST:
							case NE_SW:
								floormap[row-1][col] = INORTHWEST;
								break;
							case EAST:
							case SOUTHEAST:
							case NW_SE:
								floormap[row-1][col] = INORTHEAST;
								break;
							}
							map[row-1][col].repaint();
						}
						// check west
						if(col-1>=0) {
							wallmap[row][col-1] = WALL;
							switch(floormap[row][col-1]) {
							case GRASS:
							case NORTHWEST:
							case SOUTHWEST:
								floormap[row][col-1] = WEST;
								break;
							case EAST:
							case INORTHEAST:
							case ISOUTHEAST:
								floormap[row][col-1] = TILE;
							case TILE:
								wallmap[row][col-1] = EMPTY;
								break;
							case NORTH:
							case NORTHEAST:
							case NE_SW:
								floormap[row][col-1] = INORTHWEST;
								break;
							case SOUTH:
							case SOUTHEAST:
							case NW_SE:
								floormap[row][col-1] = ISOUTHWEST;
								break;
							}
							map[row][col-1].repaint();
						}
						// check east
						if(col+1<GRIDWIDTH) {
							wallmap[row][col+1] = WALL;
							switch(floormap[row][col+1]) {
							case GRASS:
							case NORTHEAST:
							case SOUTHEAST:
								floormap[row][col+1] = EAST;
								break;
							case WEST:
							case INORTHWEST:
							case ISOUTHWEST:
								floormap[row][col+1] = TILE;
							case TILE:
								wallmap[row][col+1] = EMPTY;
								break;
							case NORTH:
							case NORTHWEST:
							case NW_SE:
								floormap[row][col+1] = INORTHEAST;
								break;
							case SOUTH:
							case SOUTHWEST:
							case NE_SW:
								floormap[row][col+1] = ISOUTHEAST;
								break;
							}
							map[row][col+1].repaint();
						}
						// check south
						if(row+1<GRIDHEIGHT) {
							wallmap[row+1][col] = WALL;
							switch(floormap[row+1][col]) {
							case GRASS:
							case SOUTHWEST:
							case SOUTHEAST:
								floormap[row+1][col] = SOUTH;
								break;
							case NORTH:
							case INORTHWEST:
							case INORTHEAST:
								floormap[row+1][col] = TILE;
							case TILE:
								wallmap[row+1][col] = EMPTY;
								break;
							case WEST:
							case NORTHWEST:
							case NW_SE:
								floormap[row+1][col] = ISOUTHWEST;
								break;
							case EAST:
							case NORTHEAST:
							case NE_SW:
								floormap[row+1][col] = ISOUTHEAST;
								break;
							}
							map[row+1][col].repaint();
						}
						// check northwest
						if(row-1>=0 && col-1>=0) {
							wallmap[row-1][col-1] = WALL;
							switch(floormap[row-1][col-1]) {
							case GRASS:
								floormap[row-1][col-1] = NORTHWEST;
								break;
							case ISOUTHEAST:
								floormap[row-1][col-1] = TILE;
							case TILE:
								wallmap[row-1][col-1] = EMPTY;
								break;
							case SOUTHWEST:
								floormap[row-1][col-1] = WEST;
								break;
							case SOUTHEAST:
								floormap[row-1][col-1] = NW_SE;
								break;
							case EAST:
								floormap[row-1][col-1] = INORTHEAST;
								break;
							case NE_SW:
								floormap[row-1][col-1] = INORTHWEST;
								break;
							case SOUTH:
								floormap[row-1][col-1] = ISOUTHWEST;
								break;
							case NORTHEAST:
								floormap[row-1][col-1] = NORTH;
								break;
							}
							map[row-1][col-1].repaint();
						}
						// check northeast
						if(row-1>=0 && col+1<GRIDWIDTH) {
							wallmap[row-1][col+1] = WALL;
							switch(floormap[row-1][col+1]) {
							case GRASS:
								floormap[row-1][col+1] = NORTHEAST;
								break;
							case ISOUTHWEST:
								floormap[row-1][col+1] = TILE;
							case TILE:
								wallmap[row-1][col+1] = EMPTY;
								break;
							case SOUTHEAST:
								floormap[row-1][col+1] = EAST;
								break;
							case SOUTHWEST:
								floormap[row-1][col+1] = NE_SW;
								break;
							case WEST:
								floormap[row-1][col+1] = INORTHWEST;
								break;
							case NW_SE:
								floormap[row-1][col+1] = INORTHEAST;
								break;
							case SOUTH:
								floormap[row-1][col+1] = ISOUTHEAST;
								break;
							case NORTHWEST:
								floormap[row-1][col+1] = NORTH;
								break;
							}
							map[row-1][col+1].repaint();
						}
						// check southwest
						if(row+1<GRIDHEIGHT && col-1>=0) {
							wallmap[row+1][col-1] = WALL;
							switch(floormap[row+1][col-1]) {
							case GRASS:
								floormap[row+1][col-1] = SOUTHWEST;
								break;
							case INORTHEAST:
								floormap[row+1][col-1] = TILE;
							case TILE:
								wallmap[row+1][col-1] = EMPTY;
								break;
							case NORTHWEST:
								floormap[row+1][col-1] = WEST;
								break;
							case NORTHEAST:
								floormap[row+1][col-1] = NE_SW;
								break;
							case EAST:
								floormap[row+1][col-1] = ISOUTHEAST;
								break;
							case NW_SE:
								floormap[row+1][col-1] = ISOUTHWEST;
								break;
							case NORTH:
								floormap[row+1][col-1] = INORTHWEST;
								break;
							case SOUTHEAST:
								floormap[row+1][col-1] = SOUTH;
								break;
							}
							map[row+1][col-1].repaint();
						}
						// check southeast
						if(row+1<GRIDHEIGHT && col+1<GRIDWIDTH) {
							wallmap[row+1][col+1] = WALL;
							switch(floormap[row+1][col+1]) {
							case GRASS:
								floormap[row+1][col+1] = SOUTHEAST;
								break;
							case INORTHWEST:
								floormap[row+1][col+1] = TILE;
							case TILE:
								wallmap[row+1][col+1] = EMPTY;
								break;
							case NORTHEAST:
								floormap[row+1][col+1] = EAST;
								break;
							case NORTHWEST:
								floormap[row+1][col+1] = NW_SE;
								break;
							case WEST:
								floormap[row+1][col+1] = ISOUTHWEST;
								break;
							case NE_SW:
								floormap[row+1][col+1] = ISOUTHEAST;
								break;
							case NORTH:
								floormap[row+1][col+1] = INORTHEAST;
								break;
							case SOUTHWEST:
								floormap[row+1][col+1] = SOUTH;
								break;
							}
							map[row+1][col+1].repaint();
						}
					}
				}
			} else
				wallmap[row][col] = curWall;
			repaint();
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			for(int i=0; i<GRIDHEIGHT; i++) {
				for(int j=0; j<GRIDWIDTH; j++)
					System.out.print(String.format("%X", floormap[i][j]) + ",");
				System.out.print("\t");
				for(int j=0; j<GRIDWIDTH; j++)
					System.out.print(String.format("%X", wallmap[i][j]) + ",");
				System.out.println();
			}
			System.out.println();
		}

		@Override
		public void mouseEntered(MouseEvent e) {}

		@Override
		public void mouseExited(MouseEvent e) {}	
		
		@Override
	    protected void paintComponent(Graphics g) {

	        super.paintComponent(g);
                
            Insets insets = getInsets();

            int width = getWidth() - 1 - (insets.left + insets.right);
            int height = getHeight() - 1 - (insets.top + insets.bottom);

            int x = (width - floor[floormap[row][col]].getWidth(this)) / 2;
            int y = (height - floor[floormap[row][col]].getHeight(this)) / 2;

            if(floormap[row][col] == GRASS)
            	g.drawImage(grass[grassmap[row][col]], x, y, this); 
            else
            	g.drawImage(floor[floormap[row][col]], x, y, this);
            
            if(showWalls)
            	g.drawImage(wall[wallmap[row][col]], x, y, this);

	    }

	}
}
